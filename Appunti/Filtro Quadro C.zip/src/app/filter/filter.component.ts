import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FilterService } from '../filter.service';
import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {

  public selectedItemValue: any;
  public selectedItemText: string;
  public inputFieldValue: string;

  @Input() public name: string;
  @Input() public dropdownValues: DropItem[];
  @Input() public preselectedDropdownIndex: number;

  @Output() public changed: EventEmitter<ChangedFilterItem>;

  constructor(
    private svc: FilterService
  ) {
    this.changed = new EventEmitter();
  }

  public ngOnInit(): void {
    if (!this.dropdownValues || !this.dropdownValues.length) { return; }
    this.assignIdsToDropdownItems();

    this.selectedItemText =
      this.preselectedDropdownIndex === undefined
        || this.preselectedDropdownIndex === null
        ? this.dropdownValues[0].text
        : this.dropdownValues[this.preselectedDropdownIndex].text;

    this.selectedItemValue =
      this.preselectedDropdownIndex === undefined
        || this.preselectedDropdownIndex === null
        ? this.dropdownValues[0].value
        : this.dropdownValues[this.preselectedDropdownIndex].value;
  }

  public itemChange(item?: DropItem): void {
    this.selectedItemText = item ? item.text : this.selectedItemText;
    this.selectedItemValue = item ? item.value : this.selectedItemValue;
    const changedItem = {
      text: item ? item.text : this.selectedItemText,
      value: item ? item.value : this.selectedItemValue,
      inputFieldValue: this.inputFieldValue
    } as ChangedFilterItem;

    this.changed.emit(changedItem);
    this.svc.dropdownChanged = changedItem;
  }

  private assignIdsToDropdownItems(): void {
    this.dropdownValues.forEach((item, idx) => this.dropdownValues[idx].id = idx);
  }
}

export interface DropItem {
  id?: number;
  text: string;
  value: string;
}

export interface ChangedFilterItem {
  text: string;
  value: string;
  inputFieldValue: any;
}
