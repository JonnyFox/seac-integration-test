import { Component, OnInit } from '@angular/core';
import { DropItem } from './filter/filter.component';
import { FilterService } from './filter.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  public dropdownValues: DropItem[];

  public constructor(
    private svc: FilterService
  ) {
    this.dropdownValues = [
      {
        text: 'test 1',
        value: '0'
      },
      {
        text: 'test 2',
        value: '1'
      },
    ];
  }

  public ngOnInit(): void {
    this.svc
      .$dropdownChanged
      .subscribe(res => {
        console.log('The selected item has changed.');
        console.log(res);
      });
  }
}
