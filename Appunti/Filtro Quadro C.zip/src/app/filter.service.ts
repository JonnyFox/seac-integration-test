import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { ChangedFilterItem } from './filter/filter.component';

@Injectable()
export class FilterService {

  private _$dropdownChanged: BehaviorSubject<ChangedFilterItem> = new BehaviorSubject(null);

  public constructor() { }

  public set dropdownChanged(val: ChangedFilterItem) {
    this._$dropdownChanged.next(val);
  }

  public get $dropdownChanged(): Observable<ChangedFilterItem> {
    return this._$dropdownChanged.asObservable();
  }
}
